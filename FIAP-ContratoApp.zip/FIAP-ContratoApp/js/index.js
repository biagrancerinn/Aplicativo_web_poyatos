let db = null;

function ListarContratos(){
	if(db){
		const tx = db.transaction(["contratos"], "readonly"),
		      contratoStore = tx.objectStore("contratos");

		let request = contratoStore.openCursor();
		request.onerror = function(evento){
			console.log("Erro na consulta");
		};

		let tabela = $("tbody");

		tabela.empty();

		request.onsuccess = function(evento){
			let cursor = evento.target.result;
			if(cursor){

				let contrato = cursor.value;

				tabela.append("<tr><th scope=\"row\">"+contrato.codigo+"</th>"+
									"<td>"+contrato.dataIni.substring (8,10)+"/"+
					                       contrato.dataIni.substring (5,7)+"/"+
					                       contrato.dataIni.substring (0,4)+"</td>"+
									"<td>"+contrato.dataFim.substring (8,10)+"/"+
					                       contrato.dataFim.substring (5,7)+"/"+
					                       contrato.dataFim.substring (0,4)+"</td>"+
									"<td>"+contrato.tipoImo+"</td>"+
									"<td>"+contrato.formaPgto+"</td>"+
									"<td>R$"+contrato.valor+"</td>"+
									"<td>"+contrato.endereco+"</td>"+
									"<td><a class=\"btn btn-warning\" href=\"editar.html?codigo="+contrato.codigo+"\">Editar</a>"+
					                    "<button class=\"btn btn-danger\" onclick=\"ApagarContrato("+contrato.codigo+")\">Excluir</button></td></tr>");

				cursor.continue();

			}
		}
	}
}
function ApagarContrato(codigo){
	if(db){
		if(confirm("Deseja continuar com a exclusão do contrato?")){
			const txt = db.transaction(["contratos"], "readwrite"),
				contrato = txt.objectStore("contratos");
			contrato.delete(codigo);
			ListarContratos();
		}
	}
}

$(document).ready (function() {
	if(window.indexedDB) {
		let objBanco = window.indexedDB.open("contratosApp", 3);
		objBanco.onsuccess = function(evento) {
			db = evento.target.result;
			ListarContratos();
		};

		objBanco.onerror = function(evento){
			console.log("Erro na conexão com banco de dados");
		};

		objBanco.onupgradeneeded = function(evento){
			db = evento.target.result;
			let objContratos = db.createObjectStore("contratos", { keyPath: "codigo", autoIncrement: true });
		};
	} else {
		console.log("Banco de dados IndexedDB não suportado");
	}
});

window.onload = function(){
	if(window.indexedDB) {
		let db = null;
		let objBanco = window.indexedDB.open("contratosApp", 3);
		objBanco.onsuccess = function(evento){
			console.log("Conexão realizada com sucesso!");
			db = evento.target.result;
		};
		
		objBanco.onerror = function(evento){
			console.log("Erro na conexão com banco de dados");
		};
		
		objBanco.onupgradeneeded = function(evento){
			db = evento.target.result;
			let objContratos = db.createObjectStore("contratos", { keyPath: "codigo", autoIncrement: true });
		};

		$("form").submit(function(event) {
			event.preventDefault();

			const data = $( this ).serializeArray();

			let contrato = {};

			jQuery.each(data, function( i, campo ) {
				contrato[campo.name] = campo.value;
			});

			const tx = db.transaction(["contratos"], "readwrite"),
			      contratoStore = tx.objectStore("contratos");

			contratoStore.put(contrato);
			
			window.location.href = "index.html";
		});
	} else {
		console.log("Banco de dados IndexedDB não suportado");
	}
};

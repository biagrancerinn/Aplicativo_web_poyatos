let db = null;

$(document).ready (function() {
        let codigo = parseInt(getUrlParameter("codigo"));

        if(window.indexedDB) {

            let objBanco = window.indexedDB.open("contratosApp", 3);
            objBanco.onsuccess = function(evento){
                db = evento.target.result;

                let tx = db.transaction(["contratos"], "readonly");
                let contratoStore = tx.objectStore("contratos");

                let objConsulta = contratoStore.get(codigo);

                objConsulta.onsuccess = function() {
                     let contrato = objConsulta.result;

                    $("#dataIni").val(contrato.dataIni);
                    $("#dataFim").val(contrato.dataFim);
                    $("#tipoImo").val(contrato.tipoImo);
                    $("#endereco").val(contrato.endereco);
                    $("#formaPgto").val(contrato.formaPgto);
                    $("#valor").val(contrato.valor);
                    $("#descricao").val(contrato.descricao);
                };

                $("form").submit(function(event) {
                    event.preventDefault();

                    const data = $( this ).serializeArray();

                    let contrato = {
                        codigo
                    };

                    jQuery.each(data, function( i, campo ) {
                        contrato[campo.name] = campo.value;
                    });

                    const tx = db.transaction(["contratos"], "readwrite"),
                        contratoStore = tx.objectStore("contratos");

                    contratoStore.put(contrato);

                    window.location.href = "index.html";
                });

            }
        }

    });
